package fichiersPourTp.tp1;

public enum Civilite {
	HOMME, FEMME
}
